# Pack Studio 1.1.0 (Quellcode)

Neu: virtueller Raum (nichts wird in der Welt gebaut), GIF-Export in reinem Java (kein ffmpeg),
Raster-Layout wie das Kino's-Ribbon-GIF, Item-Waehler mit Icons, Live-Vorschau, Vanilla-GUI.

## Bauen
1. Auf https://fabricmc.net/develop/template/ ein Projekt fuer Minecraft 1.21.11 erzeugen (Mod-ID `packstudio`, Package `dev.packstudio`, Mod Menu als modCompileOnly).
2. Den Ordner `src/` aus diesem Zip ueber `src/` des Templates kopieren (alte Klassen RoomBuilder, RoomScreen, RoomConfig, Exporter, Pack, Anim, Recolor, Palette, ColorPickerScreen, StudioScreen entfaellt/ersetzt).
3. `./gradlew build` -> `build/libs/packstudio-1.1.0.jar`.

Der Paket `dev.packstudio.core` hat keine Minecraft-Abhaengigkeit und wurde getestet.
Die GUI-Klassen (PackStudio, StudioScreen, PackStudioModMenu) sind NICHT kompiliert/getestet (keine MC-Libs verfuegbar).
Falls der Build Fehler meldet (1.21.11-API-Namen), Log an Claude schicken.
